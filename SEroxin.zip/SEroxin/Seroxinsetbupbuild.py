import time
import sys

def typewriter_effect(text, delay=0.1):
    for letter in text:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def main():
    text_building = "Building dependencies..."
    text_checking = "Checking for Python."
    text_done = "Done. Closing in a few."

    typewriter_effect(text_building)
    time.sleep(3)
    typewriter_effect(text_checking)
    time.sleep(7)
    typewriter_effect(text_done)
    time.sleep(2)

if __name__ == "__main__":
    main()
